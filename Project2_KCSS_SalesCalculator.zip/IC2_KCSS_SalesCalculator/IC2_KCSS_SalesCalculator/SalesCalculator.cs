﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IC2_KCSS_SalesCalculator
{
    public partial class salesCalculatorForm : Form
    {
        public salesCalculatorForm()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            //prep
            decimal purchaseAmount;
                decimal tax;
                decimal amount;
            //read from
                purchaseAmount = Convert.ToDecimal(purchaseAmountTextBox.Text);
               
            //calculate amount = purchaseAmount * tax
                tax = purchaseAmount * (decimal)0.04712;
                amount = purchaseAmount + tax;
            //display
                taxLabel.Text = tax.ToString("C");
                amountLabel.Text = amount.ToString("C");
            //focus focus!
                purchaseAmountTextBox.Focus();
            //selectall
                purchaseAmountTextBox.SelectAll();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Exit button- close
            this.Close();
        }
    }
}
