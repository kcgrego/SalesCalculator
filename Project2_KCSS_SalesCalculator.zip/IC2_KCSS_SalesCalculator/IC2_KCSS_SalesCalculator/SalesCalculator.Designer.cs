﻿namespace IC2_KCSS_SalesCalculator
{
    partial class salesCalculatorForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.nameLabel = new System.Windows.Forms.Label();
            this.courseLabel = new System.Windows.Forms.Label();
            this.projectLabel = new System.Windows.Forms.Label();
            this.purchaseAmountLabel = new System.Windows.Forms.Label();
            this.hawaiiGETaxLabel = new System.Windows.Forms.Label();
            this.purchaseAmountTextBox = new System.Windows.Forms.TextBox();
            this.taxLabel = new System.Windows.Forms.Label();
            this.totalAmountLabel = new System.Windows.Forms.Label();
            this.amountLabel = new System.Windows.Forms.Label();
            this.calculateButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // nameLabel
            // 
            this.nameLabel.AutoSize = true;
            this.nameLabel.Location = new System.Drawing.Point(13, 22);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(70, 13);
            this.nameLabel.TabIndex = 0;
            this.nameLabel.Text = "Kaleb Sandin";
            // 
            // courseLabel
            // 
            this.courseLabel.AutoSize = true;
            this.courseLabel.Location = new System.Drawing.Point(13, 35);
            this.courseLabel.Name = "courseLabel";
            this.courseLabel.Size = new System.Drawing.Size(45, 13);
            this.courseLabel.TabIndex = 1;
            this.courseLabel.Text = "ITS 128";
            // 
            // projectLabel
            // 
            this.projectLabel.AutoSize = true;
            this.projectLabel.Location = new System.Drawing.Point(13, 48);
            this.projectLabel.Name = "projectLabel";
            this.projectLabel.Size = new System.Drawing.Size(135, 13);
            this.projectLabel.TabIndex = 2;
            this.projectLabel.Text = "Project #2 Sales Calculator";
            // 
            // purchaseAmountLabel
            // 
            this.purchaseAmountLabel.AutoSize = true;
            this.purchaseAmountLabel.Location = new System.Drawing.Point(13, 94);
            this.purchaseAmountLabel.Name = "purchaseAmountLabel";
            this.purchaseAmountLabel.Size = new System.Drawing.Size(122, 13);
            this.purchaseAmountLabel.TabIndex = 3;
            this.purchaseAmountLabel.Text = "Enter Purchase Amount:";
            // 
            // hawaiiGETaxLabel
            // 
            this.hawaiiGETaxLabel.AutoSize = true;
            this.hawaiiGETaxLabel.Location = new System.Drawing.Point(13, 128);
            this.hawaiiGETaxLabel.Name = "hawaiiGETaxLabel";
            this.hawaiiGETaxLabel.Size = new System.Drawing.Size(81, 13);
            this.hawaiiGETaxLabel.TabIndex = 4;
            this.hawaiiGETaxLabel.Text = "Hawaii GE Tax:";
            // 
            // purchaseAmountTextBox
            // 
            this.purchaseAmountTextBox.Location = new System.Drawing.Point(162, 94);
            this.purchaseAmountTextBox.Name = "purchaseAmountTextBox";
            this.purchaseAmountTextBox.Size = new System.Drawing.Size(100, 20);
            this.purchaseAmountTextBox.TabIndex = 0;
            // 
            // taxLabel
            // 
            this.taxLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.taxLabel.Location = new System.Drawing.Point(162, 127);
            this.taxLabel.Name = "taxLabel";
            this.taxLabel.Size = new System.Drawing.Size(100, 23);
            this.taxLabel.TabIndex = 6;
            // 
            // totalAmountLabel
            // 
            this.totalAmountLabel.AutoSize = true;
            this.totalAmountLabel.Location = new System.Drawing.Point(16, 169);
            this.totalAmountLabel.Name = "totalAmountLabel";
            this.totalAmountLabel.Size = new System.Drawing.Size(104, 13);
            this.totalAmountLabel.TabIndex = 7;
            this.totalAmountLabel.Text = "Total Amount Owed:";
            // 
            // amountLabel
            // 
            this.amountLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.amountLabel.Location = new System.Drawing.Point(162, 168);
            this.amountLabel.Name = "amountLabel";
            this.amountLabel.Size = new System.Drawing.Size(100, 23);
            this.amountLabel.TabIndex = 8;
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(55, 214);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(75, 23);
            this.calculateButton.TabIndex = 1;
            this.calculateButton.Text = "&Calculate";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(162, 214);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 2;
            this.exitButton.Text = "E&xit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // salesCalculatorForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.amountLabel);
            this.Controls.Add(this.totalAmountLabel);
            this.Controls.Add(this.taxLabel);
            this.Controls.Add(this.purchaseAmountTextBox);
            this.Controls.Add(this.hawaiiGETaxLabel);
            this.Controls.Add(this.purchaseAmountLabel);
            this.Controls.Add(this.projectLabel);
            this.Controls.Add(this.courseLabel);
            this.Controls.Add(this.nameLabel);
            this.Name = "salesCalculatorForm";
            this.Text = "Sales Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label nameLabel;
        private System.Windows.Forms.Label courseLabel;
        private System.Windows.Forms.Label projectLabel;
        private System.Windows.Forms.Label purchaseAmountLabel;
        private System.Windows.Forms.Label hawaiiGETaxLabel;
        private System.Windows.Forms.TextBox purchaseAmountTextBox;
        private System.Windows.Forms.Label taxLabel;
        private System.Windows.Forms.Label totalAmountLabel;
        private System.Windows.Forms.Label amountLabel;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Button exitButton;
    }
}

